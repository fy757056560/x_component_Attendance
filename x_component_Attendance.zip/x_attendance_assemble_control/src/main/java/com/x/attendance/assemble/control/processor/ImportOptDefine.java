package com.x.attendance.assemble.control.processor;

public class ImportOptDefine{
	/**
	 * 从EXCEL里获取数据
	 */
	public static String GETDATA = "GETDATA";
	
	/**
	 * 校验EXCEL数据
	 */
	public static String VALIDATE = "VALIDATE";

	/**
	 * 保存数据
	 */
	public static String SAVEDATA = "SAVEDATA";
	/**
	 * 补充数据
	 */
	public static String SUPPLEMENT = "SUPPLEMENT";
	/**
	 * 分析数据
	 */
	public static String ANALYSIS = "ANALYSIS";
	
	/**
	 * 处理完成
	 */
	public static String COMPLETED = "COMPLETED";
	
}
