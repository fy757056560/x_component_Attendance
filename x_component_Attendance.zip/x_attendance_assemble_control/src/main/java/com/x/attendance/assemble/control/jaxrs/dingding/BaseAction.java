package com.x.attendance.assemble.control.jaxrs.dingding;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

public class BaseAction extends StandardJaxrsAction {
}
