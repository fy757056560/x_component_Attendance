package com.x.attendance.assemble.control.jaxrs.attendanceworkdayconfig;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

public class BaseAction extends StandardJaxrsAction{
}
