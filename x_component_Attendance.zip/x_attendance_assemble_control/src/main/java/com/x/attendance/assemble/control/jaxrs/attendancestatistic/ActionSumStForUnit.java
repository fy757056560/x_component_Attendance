package com.x.attendance.assemble.control.jaxrs.attendancestatistic;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.x.attendance.entity.StatisticUnitForMonth;
import com.x.base.core.entity.JpaObject;
import com.x.base.core.project.bean.WrapCopier;
import com.x.base.core.project.bean.WrapCopierFactory;
import com.x.base.core.project.http.ActionResult;
import com.x.base.core.project.http.EffectivePerson;
import com.x.base.core.project.logger.Logger;
import com.x.base.core.project.logger.LoggerFactory;

public class ActionSumStForUnit extends BaseAction {

	private static  Logger logger = LoggerFactory.getLogger(ActionSumStForUnit.class);

	protected ActionResult<Wo> execute(HttpServletRequest request, EffectivePerson effectivePerson, String name,
			String year, String month) throws Exception {
		ActionResult<Wo> result = new ActionResult<>();
		Wo wraps = null;
		StatisticUnitForMonth statisticUnitForMonth = null;
		List<String> unitNameList = new ArrayList<String>();
		Object employeeCount = null;
		Object onDutyEmployeeCount = null;
		Object absenceDayCount = null;
		Object onSelfHolidayCount = null;
		Object lateCount = null;
		Object leaveEarlyCount = null;
		Object offDutyCount = null;
		Object onDutyCount = null;
		Object abNormalDutyCount = null;
		Object lackOfTimeCount = null;
		Boolean check = true;

		if ("(0)".equals(year)) {
			year = null;
		}
		if ("(0)".equals(month)) {
			month = null;
		}
		if (check) {
			if (name == null || name.isEmpty()) {
				check = false;
				Exception exception = new ExceptionQueryStatisticUnitNameEmpty();
				result.error(exception);
			}
		}
		if (check) {
			try {
				unitNameList = userManagerService.listSubUnitNameWithParent(name);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e, "根据组织名称列示所有下级组织名称发生异常！Unit:" + name);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			if (unitNameList == null) {
				unitNameList = new ArrayList<>();
			}
			unitNameList.add(name);
		}
		if (check) {
			try {
				absenceDayCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_AbsenceDayCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'缺勤天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				onSelfHolidayCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_OnSelfHolidayCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'请休假天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				lateCount = attendanceStatisticServiceAdv.sumUnitForMonth_LateCount_ByUnitYearAndMonth(unitNameList,
						year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'迟到天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				leaveEarlyCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_LeaveEarlyCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'早退天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				onDutyCount = attendanceStatisticServiceAdv.sumUnitForMonth_OnDutyCount_ByUnitYearAndMonth(unitNameList,
						year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'签到天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				offDutyCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_OffDutyCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'签退天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				abNormalDutyCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_AbNormalDutyCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'缺勤天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				lackOfTimeCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_LackOfTimeCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'工时不足天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			try {
				onDutyEmployeeCount = attendanceStatisticServiceAdv
						.sumUnitForMonth_AttendanceDayCount_ByUnitYearAndMonth(unitNameList, year, month);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e,
						"系统在查询组织每月统计数据中'缺勤天数'总和时发生异常.Name:" + unitNameList + ", Year:" + year + ", Month:" + month);
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		if (check) {
			double count = 0.0;
			statisticUnitForMonth = new StatisticUnitForMonth(lateCount == null ? 0 : (long) lateCount,
					leaveEarlyCount == null ? 0 : (long) leaveEarlyCount,
					offDutyCount == null ? 0 : (long) offDutyCount, onDutyCount == null ? 0 : (long) onDutyCount,
					absenceDayCount == null ? 0 : (double) absenceDayCount,
					employeeCount == null ? 0 : (double) employeeCount,
					onDutyEmployeeCount == null ? 0 : (double) onDutyEmployeeCount,
					onSelfHolidayCount == null ? 0 : (double) onSelfHolidayCount,
					lackOfTimeCount == null ? 0 : (long) lackOfTimeCount,
					abNormalDutyCount == null ? 0 : (long) abNormalDutyCount);
			if (onDutyEmployeeCount == null) {
				count = 0.0;
			} else {
				count = (double) onDutyEmployeeCount;
			}
			if (statisticUnitForMonth != null) {
				statisticUnitForMonth.setOnDutyEmployeeCount(count);
			}
		}
		if (check) {
			try {
				wraps = Wo.copier.copy(statisticUnitForMonth);
				result.setData(wraps);
			} catch (Exception e) {
				check = false;
				Exception exception = new ExceptionAttendanceStatisticProcess(e, "系统将所有查询到的组织每月统计信息对象转换为可以输出的信息时发生异常.");
				result.error(exception);
				logger.error(e, effectivePerson, request, null);
			}
		}
		return result;
	}

	public static class Wo extends StatisticUnitForMonth {

		private static final long serialVersionUID = -5076990764713538973L;

		public static WrapCopier<StatisticUnitForMonth, Wo> copier = WrapCopierFactory.wo(StatisticUnitForMonth.class,
				Wo.class, null, JpaObject.FieldsInvisible);
	}
}