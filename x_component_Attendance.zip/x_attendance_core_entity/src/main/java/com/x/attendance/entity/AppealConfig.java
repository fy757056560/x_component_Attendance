package com.x.attendance.entity;

public class AppealConfig {
	public static final String APPEAL_AUDIFLOWTYPE_WORKFLOW = "WORKFLOW"; //自定义工作流
	public static final String APPEAL_AUDIFLOWTYPE_BUILTIN = "BUILTIN";  //固定审核步骤
	public static final String APPEAL_AUDITTYPE_PERSON = "指定人";
	public static final String APPEAL_AUDITTYPE_PERSONATTRIBUTE = "个人属性";
	public static final String APPEAL_AUDITTYPE_REPORTLEADER = "汇报对象";
	public static final String APPEAL_AUDITTYPE_UNITDUTY = "所属部门职务";
	public static final String APPEAL_CHOOSEVALUE_AUDITTYPE = "指定人|个人属性|汇报对象|所属部门职务";
	public static final String APPEAL_CHOOSEVALUE_CHECKTYPE = "无|指定人|个人属性|汇报对象|所属部门职务";
}
