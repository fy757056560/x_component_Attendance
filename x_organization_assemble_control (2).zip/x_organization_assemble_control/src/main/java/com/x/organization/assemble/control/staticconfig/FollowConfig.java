package com.x.organization.assemble.control.staticconfig;

public final class FollowConfig {
	public static final String QRPATH = "/data/appdevServer/servers/webServer/QRcode/";
	public static final String LOGOPATH = "/data/appdevServer/servers/webServer/QRcode/";
	public static final String VCFPATH = "/data/appdevServer/servers/webServer/QRcode/";
}
