package com.x.organization.assemble.control.jaxrs.loginrecord;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}