package com.x.organization.assemble.authentication.jaxrs.qiyeweixin;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

}
