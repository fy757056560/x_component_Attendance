package com.x.organization.assemble.authentication.jaxrs.bind;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

class BaseAction extends StandardJaxrsAction {

}
