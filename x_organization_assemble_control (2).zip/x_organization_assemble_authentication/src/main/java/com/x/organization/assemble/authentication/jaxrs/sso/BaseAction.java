package com.x.organization.assemble.authentication.jaxrs.sso;

import com.x.base.core.project.jaxrs.StandardJaxrsAction;

abstract class BaseAction extends StandardJaxrsAction {

	protected final String TOKEN_SPLIT = "#";

}
